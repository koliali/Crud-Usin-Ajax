-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `ajax` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `ajax`;

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PhoneNumber` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `user` (`ID`, `Name`, `Email`, `PhoneNumber`) VALUES
(1,	'mohsin',	'mohsinrao.alui@gmail.comn',	'+9856456496'),
(2,	'mohsin123',	'mohsinrao.alui@gmail.comn',	'+9856456496'),
(3,	'ali',	'ali@gmail.com',	'+5984851'),
(4,	'ali',	'ali@gmail.com',	'6649549749'),
(5,	'oipo',	'op@gmail.com',	'+6985494941'),
(6,	'erp',	'erp@gmail.com',	'+541964156'),
(7,	'jojo',	'jo@gmail.com',	'+8989541941'),
(9,	'bilal',	'bil@gmail.com',	'+95984961'),
(10,	'koli',	'koli@gmail.com',	'+598491'),
(11,	'joe',	'joe@gmail.com',	'+594161'),
(12,	'rehamn',	'rehman@gmail.com',	'+96464164161'),
(13,	'sundeep',	'asun@gmail.com',	'+9956696416'),
(14,	'abc',	'abc@gmail.com',	'+65494944'),
(15,	'asr',	'saaser@gmail.com',	'+564984'),
(16,	'ako',	'ako@gmail.com',	'+9649419643641'),
(17,	'aloy',	'aloy@gmail.com',	'+949649499496'),
(18,	'alloogo',	'aloogio@gmail.com',	'+9489494954'),
(19,	'koalwe',	'atgkwb@gmail.com',	'+59496415641634');

-- 2017-08-18 15:40:32
